---
description: 현재 변경사항을 GitHub에 자동으로 푸시합니다.
---

1. `git status`를 실행하여 변경 사항을 확인합니다.
2. `git add .` 명령어를 실행하여 모든 변경 사항을 스테이징합니다.
// turbo
3. 변경 사항을 요약하는 적절한 커밋 메시지와 함께 `git commit -m "..."`을 실행합니다.
// turbo
4. `git push`를 실행하여 원격 저장소에 업로드합니다.
